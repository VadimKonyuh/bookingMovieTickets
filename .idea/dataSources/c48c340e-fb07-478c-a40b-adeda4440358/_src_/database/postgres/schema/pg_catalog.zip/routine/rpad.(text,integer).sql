create function rpad(text, integer) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.rpad($1, $2, ' ')
$$;
