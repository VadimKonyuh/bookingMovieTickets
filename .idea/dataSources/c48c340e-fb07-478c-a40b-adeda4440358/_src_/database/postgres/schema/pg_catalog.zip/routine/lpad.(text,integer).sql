create function lpad(text, integer) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.lpad($1, $2, ' ')
$$;
